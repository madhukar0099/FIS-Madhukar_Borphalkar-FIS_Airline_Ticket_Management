package com.example.fisairlineadmin.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.fisairlineadmin.modal.Adminrole;

public interface AdminroleRepository extends JpaRepository<Adminrole,Integer> {

}
