package com.example.fisgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FisgatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
